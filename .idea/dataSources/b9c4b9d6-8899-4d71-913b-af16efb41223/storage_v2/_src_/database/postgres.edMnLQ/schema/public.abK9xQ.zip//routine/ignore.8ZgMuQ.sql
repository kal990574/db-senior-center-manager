create function ignore() returns trigger
    language plpgsql
as
$$ BEGIN IF exists (select * from College where cName = New.cName) THEN return null; ELSE return New; END IF; END; $$;

alter function ignore() owner to mambasa;

