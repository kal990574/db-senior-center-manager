create view csee(sid, cname, major) as
SELECT sid,
       cname,
       major
FROM apply
WHERE major::text = 'CS'::text
   OR major::text = 'EE'::text;

alter table csee
    owner to mambasa;

