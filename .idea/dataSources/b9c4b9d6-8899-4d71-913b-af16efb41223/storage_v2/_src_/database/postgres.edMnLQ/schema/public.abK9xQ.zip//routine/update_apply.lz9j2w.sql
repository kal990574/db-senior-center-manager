create function update_apply() returns trigger
    language plpgsql
as
$$ BEGIN UPDATE Apply SET cName = NEW.cName WHERE cName = OLD.cName;return NEW; END; $$;

alter function update_apply() owner to mambasa;

