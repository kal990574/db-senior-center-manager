create function csee_insert() returns trigger
    language plpgsql
as
$$BEGIN IF New.major = 'CS' or New.major = 'EE'then insert into Apply values (New.sID, New.cName, New.major, null);return NULL; END IF; return NULL; END; $$;

alter function csee_insert() owner to mambasa;

